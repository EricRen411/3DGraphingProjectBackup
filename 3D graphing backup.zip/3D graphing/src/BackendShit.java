import java.awt.Point;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Arrays;

public class BackendShit {
	
	public double[] cameraAngleDegrees; //extrinsic
	public double[] cameraPosition;
	public double fov;
	public double backboardDistance;
	
	public BackendShit() {
		cameraAngleDegrees = new double[3];
		cameraAngleDegrees[0] = 0;
		cameraAngleDegrees[1] = 0;
		cameraAngleDegrees[2] = 0;
		cameraPosition = new double[3];
		cameraPosition[0] = -1;
		cameraPosition[1] = 0;
		cameraPosition[2] = 0;
		fov = 100;
		backboardDistance = 50;
	}
	
	public double[] parametricfunction(double t) {
		double[] point = new double[3];
		
		point[0] = t;
		point[1] = Math.cos(t);
		point[2] = Math.sin(t);
		
		return point;
	}
	
	public double[] cameraPositionTransform(double[] originalCoords) {
		double[] result = new double[3];
		result[0]= originalCoords[0]-cameraPosition[0];
		result[1] = originalCoords[1]-cameraPosition[1];
		result[2] = originalCoords[2]-cameraPosition[2];
		return result;
	}
	
	public double[] cameraAngleTransformX(double[] positionTransformedCoords) {
		double[] result = new double[3];
		double xRotRadians = cameraAngleDegrees[0];
		double x = positionTransformedCoords[0];
		double y = positionTransformedCoords[1];
		double z = positionTransformedCoords[2];
		
		result[0] = x;
		result[1] = Math.cos(xRotRadians)*y-Math.sin(xRotRadians)*z;
		result[2] = Math.sin(xRotRadians)*y+Math.cos(xRotRadians)*z;
		
		return result;
	}
	
	public double[] cameraAngleTransformY(double[] positionTransformedCoords) {
		double[] result = new double[3];
		double yRotRadians = cameraAngleDegrees[1];
		double x = positionTransformedCoords[0];
		double y = positionTransformedCoords[1];
		double z = positionTransformedCoords[2];
		
		result[0] = Math.cos(yRotRadians)*x+Math.sin(yRotRadians)*z;
		result[1] = y;
		result[2] = -Math.sin(yRotRadians)*x+Math.cos(yRotRadians)*z;
		
		return result;
	}
	
	public double[] cameraAngleTransformZ(double[] positionTransformedCoords) {
		double[] result = new double[3];
		double zRotRadians = cameraAngleDegrees[2];
		double x = positionTransformedCoords[0];
		double y = positionTransformedCoords[1];
		double z = positionTransformedCoords[2];
		
		result[0] = Math.cos(zRotRadians)*x-Math.sin(zRotRadians)*y;
		result[1] = Math.sin(zRotRadians)*x+Math.cos(zRotRadians)*y;
		result[2] = z;
		
		return result;
	}
	
	public double[] projection(double[] fullyTransformedCoords) {
		//Assumes only Coord within fov is passed in
		double[] result = new double[2];
		double x = fullyTransformedCoords[0];
		double y = fullyTransformedCoords[1];
		double z = fullyTransformedCoords[2];
		
		
		result[0] = y*backboardDistance/x;
		result[1] = z*backboardDistance/x;
		
		return result;
		
	}
	
	public double[] cameraTransform(double[] rawInput) {
		
		double[] beforeProjection = 
			this.cameraAngleTransformX(
				this.cameraAngleTransformY(
						this.cameraAngleTransformZ(
								this.cameraPositionTransform(
										rawInput))));
				
		if (beforeProjection[0]<=0) {
			return new double[]{5000,5000};
		} else {
			return projection(beforeProjection);
		}
		
	}
	
	public Point coordToPixelLocation(double[] transformedCoords, int xPanelSize, int yPanelSize) {
		//We've projected points onto the backboard and now want to figure out which pixel position 
		//the raw numbers correspond to. We want to include a portion of the backboard depending on fov. tan(fov/2) = bounds/backboarddistance
		
		Point result = new Point();
		
		double y = transformedCoords[0];
		double z = transformedCoords[1];
		
		double Bounds = backboardDistance*Math.tan(fov*Math.PI/180);
		
		if (y==5000||z==5000) {
			result.setLocation(y,z);
		}
		else if (Math.abs(y)<=Bounds||Math.abs(z)<=Bounds) {
			result.setLocation(5000,5000);
		}
		else {
		int newx = (int) (xPanelSize/2+y*xPanelSize/(2*Bounds));
		int newy = (int) (yPanelSize/2-z*yPanelSize/(2*Bounds));
		result.setLocation(newx, newy);
		
		}
		return result;
	}
	
	public ArrayList<Point> PixelPoints(int xPanelSize, int yPanelSize) {
		ArrayList<Point> result = new ArrayList<Point>();
		for (int i = 0; i<500; i++) {
			double[] originalCoords = this.parametricfunction(i/50);
			double[] transformedCoords = this.cameraTransform(originalCoords);
			Point finalPoint = this.coordToPixelLocation(transformedCoords, xPanelSize, yPanelSize);
			result.add(finalPoint);
		}
		return result;
	}
	
	public ArrayList<double[]> threeDPoints() {
		ArrayList<double[]> result = new ArrayList<double[]>();
		for (int i = 0; i<50; i++) {
			result.add(parametricfunction(i/5));
		}
		return result;
	}
	
//public static void main(String[] args) {
	//BackendShit test = new BackendShit();
	//System.out.println(test.coordToPixelLocation(test.projection(test.parametricfunction(1)),1000,1000));
	
//}
	
	
}
