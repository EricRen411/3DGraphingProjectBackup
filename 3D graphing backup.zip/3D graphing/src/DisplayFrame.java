import java.awt.EventQueue;
import java.awt.Point;
import java.util.ArrayList;

import javax.swing.JFrame;

public class DisplayFrame extends JFrame {
	public DisplayFrame(ArrayList<Point> arrayList) {
		DisplayPointsPanel panel = new DisplayPointsPanel(arrayList);
		add(panel);
		setTitle("Graph");
        setSize(1000, 1000);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static void main(String[] args) {
		BackendShit b = new BackendShit();
		ArrayList<Point> p = DisplayPointsPanel.testPoints();
            	DisplayFrame d = new DisplayFrame(b.PixelPoints(1000, 1000));
            	d.setVisible(true);
	}
	
}

