
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.util.ArrayList;

import javax.swing.JPanel;

public class DisplayPointsPanel extends JPanel {

	public ArrayList<java.awt.Point> AxisEnds;
	public ArrayList<java.awt.Point> Points;
	
	public static ArrayList<Point> testPoints() {
		ArrayList<Point> result = new ArrayList<Point>();
		for (int i = 0; i<1000; i++) {
			result.add(new Point(i, i));
		}
		return result;
	}
	
	public DisplayPointsPanel(ArrayList<Point> Points) {
		this.Points = Points;
	}
	
	public DisplayPointsPanel(ArrayList<Point> Points, ArrayList<Point> AxisEnds) {
		this.AxisEnds = AxisEnds;
		this.Points = Points;
	}
	
	private void doDrawing(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		
		int x1;
		int x2;
		int y1;
		int y2;
		/*
		for (int i = 0; i< this.AxisEnds.size(); i++) {
			g.setColor(java.awt.Color.black);
			x1 = 0;
			y1 = 0;
			x2 = (int) this.AxisEnds.get(i).getX();
			y2 = (int) this.AxisEnds.get(i).getY();
			
			g2d.drawLine(x1, y1, x2, y2);
		}
		*/
		
		for (int i = 0; i < this.Points.size()-1;i++) {
			g.setColor(java.awt.Color.blue);
			x1 = (int) this.Points.get(i).getX();
			x2 = (int) this.Points.get(i+1).getX();
			y1 = (int) this.Points.get(i).getY();
			y2 = (int) this.Points.get(i+1).getY();
			if (x1 == 5000 || x2 == 5000 || y1 == 5000 || y2 == 5000) {
				
			} else {
			g2d.drawLine(x1, y1, x2, y2);
			}
		}
	
	}
	@Override
	public void paintComponent(Graphics g) {

        super.paintComponent(g);
        doDrawing(g);
    }

}